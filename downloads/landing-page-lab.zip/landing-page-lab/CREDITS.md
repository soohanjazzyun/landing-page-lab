# Credits and license

Landing Page Lab is an independent project by Jazz.
Published ideas informing the three perspectives: Donald Miller, Building a StoryBrand; Seth Godin, This Is Marketing; Alex Hormozi, $100M Offers.
Not affiliated with, certified by, or endorsed by these authors or their organizations.
Original instructions and code are MIT licensed; third-party books, websites, graphics, and brands are not relicensed. No official worksheets or PDFs are included.
This is not a representation of legal clearance. See source history and limitations:
https://github.com/soohanjazzyun/landing-page-lab/blob/main/docs/rights-review.md
